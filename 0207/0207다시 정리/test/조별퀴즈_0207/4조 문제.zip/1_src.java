package J200207;

import java.util.Scanner;

public class Exam1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int Arr[] = new int[10];
		int num;
		int diff, min = 999, result = 0;

		System.out.println("���� �߻�!");

		for (int i = 0; i < Arr.length; i++) {
			Arr[i] = (int) (Math.random() * 100) + 1;
			System.out.print(Arr[i] + "\t");
		}
		System.out.println("\n");

		do {
			System.out.print("������ �� ? ");
			num = sc.nextInt();
		} while (num < 0 || num > 100);

		for (int i = 0; i < Arr.length; i++) {
			diff = Arr[i] > num ? (Arr[i] - num) : (num - Arr[i]);
				if (i == 0 || min > diff) {
					min = diff;
					result = Arr[i];
				}
		}
		
		System.out.println(num+"�� ���� �������� "+result);
		
		
		sc.close();
	}
}
