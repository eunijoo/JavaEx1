package tesr0207;

import java.util.Scanner;

//양의 정수 10개를 입력받아 배열에 저장하고, 배열에 있는 정수 중에서 3의 배수만 출력

public class Quiz {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int num[] = new int[10];
		int tot = 0;

		System.out.print("양의 정수 10개를 입력하세요.");
		for (int i = 0; i < num.length; i++) {
				num[i] = sc.nextInt();
				if(num[i] < 0)
				{
					System.out.print("양수만 입력하세요.");
					i--;
					continue;
				}
			}

		for (int i = 0; i < num.length; i++) {
			if (num[i] % 3 == 0) {
				System.out.print(num[i] + " ");
			}
		}
	}
}
