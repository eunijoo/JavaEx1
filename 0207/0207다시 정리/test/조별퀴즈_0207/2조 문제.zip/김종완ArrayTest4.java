package test0207;

import java.util.Scanner;

public class ArrayTest4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int []a = new int[5];
		
		System.out.println("�� 5���Է� : ");
		
		for(int i = 0; i<5; i++) {
			a[i] = sc.nextInt();
			
		}
		
		
		
		System.out.print("�Է��Ѽ� : ");
		for(int i = 0; i<5; i++) System.out.print(a[i] + " ");
		
		
		System.out.print("�ݴ����� : ");
		for(int i = 4; i>=0 ; i--) System.out.print(a[i] + " ");
			
		sc.close();
	}

}
